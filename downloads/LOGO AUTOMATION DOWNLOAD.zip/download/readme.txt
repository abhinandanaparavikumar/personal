Best run with IDLE. It comes with Python when you install it.
Run IDLE from start and open the script zz.py and run the module.
A 'withlogo' folder will be created with the logo placed in the bottom left corner.

zz.py basically places the logo at a certain location which was decided upon discussion with the members to
look pleasing aesthetically. Since, the photos were usually certain dimensions, this time-consuming process
when done manually, was easy to automate using Python libraries.

change logo colour.py is pretty self explanatory.


I dont own the rights to the U-BASE logo. It belongs the United Building and Structural Engineering Association 
of TU Delft. Kindly look up their copyright and licensing information if you would like to use it anywhere.