import os
from PIL import Image, ImageOps
#for 3200 something fixed_height = 220
#for 6000x4000 = 335
fixed_height = 166
logo_file = 'logo.png'
logoIm = Image.open(logo_file).convert('RGBA') 
height_percent = (fixed_height / float(logoIm.size[1]))
width_size = int((float(logoIm.size[0]) * float(height_percent)))
logoIm = logoIm.resize((width_size, fixed_height))
print(logoIm.size)
#logoIm = logoIm.resize((605,335))
logoWidth, logoHeight = logoIm.size
#print(logoIm.size)
os.makedirs('withlogo',exist_ok = True)
for filename in os.listdir('.'):
  if not (filename.endswith('.PNG') or filename.endswith('.jpg') or filename.endswith('.JPG') or filename.endswith('.HEIC')) or filename == logo_file:
    continue
  originalim = Image.open(filename)
  fixedim = ImageOps.exif_transpose(originalim)
  print(fixedim.size)
  width, height = fixedim.size
  #print(im.size)
  #if width > sq_fit_size and height > sq_fit_size:
    #if width > height:
      #height = int((sq_fit_size / width) * height)
      #width = sq_fit_size
    #else:
      #width = int((sq_fit_size / height) * width)
      #height = sq_fit_size
    #print("Resizing %s"% (filename)) 
    #im = im.resize((width, height))
  #usually for 335 its - 200
  fixedim.paste(logoIm, (width - logoWidth - 99, height - logoHeight - 99), logoIm)
  #bottom left corner below one
  #fixedim.paste(logoIm, (99, height - logoHeight - 99), logoIm)
  fixedim.save(os.path.join('withlogo', filename))
