from PIL import Image
import numpy as np
img = Image.open("logo.png")
print (img.mode)
print(img.size)
width = img.size[0] 
height = img.size[1] 
for i in range(0,width):# process all pixels
    for j in range(0,height):
        data = img.getpixel((i,j))
        #print(data) #(255, 255, 255)
        if (data[0]==255 and data[1]==255 and data[2]==255 and data[3]==255):
            img.putpixel((i,j),(200,200,200,255))
        #if (data[0]==255 and data[1]==255 and data[2]==255 and data[3]==0):
            #img.putpixel((i,j),(89,95,105,0))
img.save("logo_grey.png")
